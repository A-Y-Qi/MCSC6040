#include "stdio.h"
#include "stdlib.h"
#include "math.h"

//#define Nmp 500
#define Nsp 100000
#define Nmp 10026
#define PI 3.14159265

int main()
{
    float R = 0.05;        //The radius of the large particles
    float epsilon = 0.1;   //The ratio of particle sizes r/R
    float r = epsilon * R; //The radius of the small particle
    float D = 1;           //Small particle diffusion coefficient
    float dt = 0.00001;    //Simulation time-step, should be as small as feasible
    float propx = 0;
    float propy = 0;
    float propz = 0;
    float t = 0;     //time
    double tmax = 3; //maxtime
    int Lx = 20;
    int Ly = 1; //length of the box
    int Lz = 1; //length of the box

    float k = 0.52;

    float ran1, ran2, ran3, ran4;  // pseudo Random numbers with normal distribution
    float gr1, gr2, gr3;           //normal random numbers
    double X[Nmp], Y[Nmp], Z[Nmp]; //position of macro particles
    double x[Nsp];
    double y[Nsp], z[Nsp]; //position of small particles
    int kpp, tooclose;     //indicator about whether to keep place or not to keep the position
    double distance;
    int intstep = 0;
    int flag = 0;

    int i, j;

    FILE *outin, *outx, *outtrj, *outin2;
    outin = fopen("R3Dstep.xyz", "w");
    outin2 = fopen("R3Dstep.dat", "w");
    outx = fopen("rs3Dstep.dat", "w");
    outtrj = fopen("rs3Dstep.xyz", "w");

    fprintf(outin, "%i\n", Nmp - 1);
    //place all obstacles
    for (i = 0; i < Nmp; i++)
    {
        kpp = 0;

        while (!kpp)
        {
            ran1 = 10 * (float)rand() / RAND_MAX;

            if (i < Nmp)
            {
                X[i] = ran1+R+r;
                Y[i] = (float)rand() / RAND_MAX * Ly;
                Z[i] = (float)rand() / RAND_MAX * Lz;
            }
            tooclose = 0;

            for (j = 0; j < i; j++)
            {
                distance = sqrt(pow(X[i] - X[j], 2.0) + pow(Y[i] - Y[j], 2.0) + pow(Z[i] - Z[j], 2.0));
                if (distance < 2 * R)
                {
                    tooclose = 1;
                    break;
                }
            }
            if (!tooclose)
            {
                kpp = 1;
            }
        }
        fprintf(outin, "a%i %f  %f  %f\n", i, X[i], Y[i], Z[i]);
        fprintf(outin2, "%i %f  %f  %f\n", i, X[i], Y[i], Z[i]);
    }

    //place initial position for small particles
    fprintf(outtrj, "%i\n", Nsp - 1);
    for (i = 0; i < Nsp; i++)
    {
        flag = 1;
        while (flag != 0)
        {
            ran2 = (float)rand() / RAND_MAX;
            ran3 = (float)rand() / RAND_MAX;
            propz = ran2 * Lz;
            propy = ran3 * Ly;
            propx = 0;
            flag = 0;

            for (j = 0; j < Nmp; j++)
            {
                distance = sqrt(pow(propx - X[j], 2.0) + pow(propy - Y[j], 2.0) + pow(propz - Z[j], 2.0));
                if (distance < r + R)
                {
                    flag = 1;
                    break;
                }
                else
                {
                    flag = 0;
                }
            }

            if (flag == 0)
            {
                x[i] = propx;
                y[i] = propy;
                z[i] = propz;
            }
        }
    }
    //time loop for small particles
    while (t < tmax)
    {
        if (intstep % 1000 == 0)
        {
            fprintf(outtrj, "%i\n", Nsp - 1);
        }

        for (i = 0; i < Nsp; i++)
        {
            ran1 = (float)rand() / RAND_MAX;
            ran2 = (float)rand() / RAND_MAX;
            ran3 = (float)rand() / RAND_MAX;
            ran4 = (float)rand() / RAND_MAX;
            gr1 = (double)sqrt(-2 * log(ran1)) * cos(2 * 3.14159265 * ran2);
            gr2 = (double)sqrt(-2 * log(ran1)) * sin(2 * 3.14159265 * ran2);
            gr3 = (double)sqrt(-2 * log(ran3)) * sin(2 * 3.14159265 * ran4);
            propx = x[i] + sqrt(2 * D * dt) * gr1;
            propy = y[i] + sqrt(2 * D * dt) * gr2;
            propz = z[i] + sqrt(2 * D * dt) * gr3;
            flag = 0;
            
            if (propy < 0 || propy > Ly || propz < 0 || propz > Lz) //if the particle want to go beyond the boundary of z and y
            {
                flag = 1;
            }
            else if (propx < -r - R) //if the small particle reaches the no obstacle zone
            {
                flag = 0;
            }
            else
            {
                for (j = 0; j < Nmp; j++)
                {
                    distance = sqrt(pow(propx - X[j], 2.0) + pow(propy - Y[j], 2.0) + pow(propz - Z[j], 2.0));
                    if (distance < r + R || propy < 0 || propy > 1 || propz < 0 || propz > 1)
                    {
                        flag = 1;
                        break;
                    }
                }
            }
            if (flag == 0)
            {
                x[i] = propx;
                y[i] = propy;
                z[i] = propz;

                //periodic boundary in x
                if (x[i] > Lx / 2)
                {
                    x[i] = x[i] - Lx;
                }
                if (x[i] < -Lx / 2)
                {
                    x[i] = x[i] + Lx;
                }
            }
            if (intstep % 1000 == 0)
            {
                fprintf(outtrj, "a%i    %f  %f  %f\n", i, x[i], y[i], z[i]);
                fprintf(outx, "%f\n", x[i]);
            }
        }

        t = t + dt;
        intstep++;

        if (intstep % 1000 == 0)
        {
            printf("now we are at %f\n", t);
        }
    }
}
