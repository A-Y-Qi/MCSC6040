#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "time.h"

//#define Nmp 668
#define Nmp 167
#define Nsp 10000
#define PI 3.14159265

int main()
{
    float R = 0.1;         //The radius of the large particles
    float epsilon = 0.1;   //The ratio of particle sizes r/R
    float r = epsilon * R; //The radius of the small particle
    float D = 1;           //Small particle diffusion coefficient
    float dt = 0.00001;    //Simulation time-step, should be as small as feasible

    float propx = 0;
    float propy = 0;
    float v[Nsp];    //velocity of the particles
    float t = 0;     //time
    double tmax = 0.3; //maxtime
    int Lx = 20;
    int Ly = 1; //length of the box
    float ptumble = 0.001;
    float prun = 0.01;
    float k = 0.52;

    float ran1, ran2, ran3, ran4; // pseudo Random numbers with normal distribution
    float gr1, gr2, gr3;          //normal random numbers
    double X[Nmp], Y[Nmp];        //position of macro particles
    double x[Nsp] = {0};
    double y[Nsp];     //position of small particles
    double theta[Nsp]; //angles of each particle
    float dtheta = PI; //change of angles
    int kpp, tooclose; //indicator about whether to keep place or not to keep the position
    double distance;
    int intstep = 0;
    int flag = 0;
    int state[Nsp];

    int i, j;

    FILE *outin, *outx, *outtrj, *outin2;
    outin = fopen("RStepSWMranddisp.xyz", "w");
    outin2 = fopen("RStepSWMranddisp.dat", "w");
    outx = fopen("rsStepSWMranddisp.dat", "w");
    outtrj = fopen("rsStepSWMranddisp.xyz", "w");

    time_t first, second;

    fprintf(outin, "%i\n", Nmp - 1);

    //Initial condition for large particles
    for (i = 0; i < Nmp; i++)
    {
        kpp = 0;

        while (!kpp)
        {
            ran1 = 10 * (float)rand() / RAND_MAX;

            if (i < Nmp)
            {
                X[i] = ran1 + r + R;
                Y[i] = (float)rand() / RAND_MAX * Ly;
            }

            tooclose = 0;

            for (j = 0; j < i; j++)
            {
                distance = sqrt(pow(X[i] - X[j], 2.0) + pow(Y[i] - Y[j], 2.0));
                if (distance < 2 * R)
                {
                    tooclose = 1;
                }
            }
            if (!tooclose)
            {
                kpp = 1;
            }
        }
        fprintf(outin, "a%i %f  %f  0\n", i, X[i], Y[i]);
        fprintf(outin2, "%i %f  %f  0\n", i, X[i], Y[i]);
    }

    //initial condition for small particles
    time(&first);
    for (i = 0; i < Nsp; i++)
    {
        flag = 1;
        ran1 = (float)rand() / RAND_MAX;
        ran2 = (float)rand() / RAND_MAX;
        gr1 = fabs(sqrt(-2 * log(ran1)) * cos(2 * 3.14159265 * ran2));
        v[i] = sqrt(2 / dt) * gr1;
        theta[i] += PI * (2 * ran1 - 1.0); // randomnize at all angles
        state[i] = 1;
        while (flag != 0)
        {
            ran2 = (float)rand() / RAND_MAX;
            propy = ran2 * Ly;
            propx = 0;
            flag = 0;

            for (j = 0; j < Nmp; j++)
            {
                distance = sqrt(pow(propx - X[j], 2.0) + pow(propy - Y[j], 2.0));
                if (distance < r + R)
                {
                    flag = 1;
                    break;
                }
                else
                {
                    flag = 0;
                }
            }

            if (flag == 0)
            {
                x[i] = propx;
                y[i] = propy;
            }
        }
    }

    //time loop starts

    while (t < tmax)
    {
        if (intstep % 100 == 0)
        {
            fprintf(outtrj, "%i\n", Nsp - 1);
        }
        for (i = 0; i < Nsp; i++)
        {
            flag = 0;
            if (state[i] == 1) //running state
            {
                ran1 = (float)rand() / RAND_MAX;
                propx = x[i] + v[i] * dt * cos(theta[i]);
                propy = y[i] + v[i] * dt * sin(theta[i]);

                if (ran1 > ptumble) //if the particle keeps running
                {
                    if (propy < 0 || propy > Ly)
                    {
                        flag = 1;
                    }
                    else if (propx < -r - R)
                    {
                        flag = 0;
                    }
                    else
                    {
                        for (j = 0; j < Nmp; j++)
                        {
                            distance = sqrt(pow(propx - X[j], 2.0) + pow(propy - Y[j], 2.0));
                            if (distance < r + R)
                            {
                                flag = 1;
                                break;
                            }
                        }
                    }
                    if (flag == 0) //if the particle is not too close with obstacles
                    {
                        x[i] = propx;
                        y[i] = propy;

                        if (x[i] > Lx / 2)
                        {
                            x[i] = x[i] - Lx;
                        }
                        if (x[i] < -Lx / 2)
                        {
                            x[i] = x[i] + Lx;
                        }
                    }
                    else //if too close or hit the boundary then change its running direction and velocity
                    {
                        ran1 = (float)rand() / RAND_MAX;
                        theta[i] += dtheta * (2 * ran1 - 1.0);
                        ran2 = (float)rand() / RAND_MAX;
                        gr1 = fabs(sqrt(-2 * log(ran1)) * cos(2 * 3.14159265 * ran2));
                        v[i] = sqrt(2 / dt) * gr1;
                    }
                }
                if (ran1 < ptumble) // change to tumbling state
                {
                    state[i] = 0;
                }
            }
            if (state[i] == 0) //tumbling state
            {
                ran1 = (float)rand() / RAND_MAX;
                theta[i] += dtheta * (2 * ran1 - 1.0); //update torking angle
                if (ran1 < prun)                       //change to running state
                {
                    state[i] = 1;
                }
            }

            if (intstep % 100 == 0)
            {
                fprintf(outtrj, "a%i    %f  %f  0\n", i, x[i], y[i]);
                fprintf(outx, "%f\n", x[i]);
            }
        }
        intstep++;
        t += dt;
        if (intstep % 1000 == 0)
        {
            printf("now we are at %f\n", t);
        }
    }
}
